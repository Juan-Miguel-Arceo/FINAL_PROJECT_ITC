document.addEventListener('DOMContentLoaded', () => {

    const isInViewport = (element) => {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    };

 
    const animateOnScroll = () => {
        const fadeIns = document.querySelectorAll('.fade-in');
        const heroTexts = document.querySelectorAll('.hero-text-1, .hero-text-2, .hero-text-3, .hero-text-4');
        const images = document.querySelectorAll('.right-photo, .left-photo');
        const footerElements = document.querySelectorAll('footer ul li, .logo-1');

        fadeIns.forEach((el) => {
            if (isInViewport(el)) {
                el.classList.add('visible');
            }
        });

        heroTexts.forEach((text) => {
            if (isInViewport(text)) {
                text.classList.add('show');
            }
        });

        images.forEach((img) => {
            if (isInViewport(img)) {
                img.classList.add('show');
            }
        });

        footerElements.forEach((el) => {
            if (isInViewport(el)) {
                el.classList.add('visible');
            }
        });
    };


    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll();


    function smoothScroll(targetId) {
        const targetElement = document.getElementById(targetId);
        if (targetElement) {
            window.scrollTo({
                top: targetElement.offsetTop,
                behavior: 'smooth'
            });
        }
    }

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            smoothScroll(this.getAttribute('href').slice(1));
        });
    });
});