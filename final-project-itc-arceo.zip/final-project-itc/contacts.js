document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form');
    const inputs = document.querySelectorAll('input, textarea');

    // Function to validate input fields
    function validateInput(input) {
        if (input.required && !input.value.trim()) {
            input.classList.add('invalid');
            input.setCustomValidity('This field is required.');
        } else {
            input.classList.remove('invalid');
            input.setCustomValidity('');
        }
    }

    // Add event listeners to each input
    inputs.forEach(input => {
        input.addEventListener('blur', () => validateInput(input));
    });

    // Handle form submission
    form.addEventListener('submit', (event) => {
        // Prevent default form submission behavior
        event.preventDefault();

        // Validate all inputs
        inputs.forEach(validateInput);

        // If there are no invalid inputs, submit the form
        if (!Array.from(inputs).some(input => input.classList.contains('invalid'))) {
            // You can add your form submission logic here
            console.log('Form submitted successfully!');
            // Reset the form
            form.reset();
        }
    });
});